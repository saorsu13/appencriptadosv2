import React from "react";
import Svg, { Mask, Rect, G, Path } from "react-native-svg";

interface SvgComponentProps {
  width?: number | string;
  height?: number | string;
  color?: string;
}

const Contrast: React.FC<SvgComponentProps> = ({
  width = "24",
  height = "24",
  color = "white",
}) => (
  <Svg width={width} height={height} viewBox="0 0 24 24">
    <Mask
      id="mask0_1983_543"
      maskUnits="userSpaceOnUse"
      x="0"
      y="0"
      width="24"
      height="24"
    >
      <Rect width="24" height="24" fill="#D9D9D9" />
    </Mask>
    <G mask={`url(#mask0_1983_543)`}>
      <Path
        d="M12 22C10.6167 22 9.31667 21.7375 8.1 21.2125C6.88333 20.6875 5.825 19.975 4.925 19.075C4.025 18.175 3.3125 17.1167 2.7875 15.9C2.2625 14.6833 2 13.3833 2 12C2 10.6167 2.2625 9.31667 2.7875 8.1C3.3125 6.88333 4.025 5.825 4.925 4.925C5.825 4.025 6.88333 3.3125 8.1 2.7875C9.31667 2.2625 10.6167 2 12 2C13.3833 2 14.6833 2.2625 15.9 2.7875C17.1167 3.3125 18.175 4.025 19.075 4.925C19.975 5.825 20.6875 6.88333 21.2125 8.1C21.7375 9.31667 22 10.6167 22 12C22 13.3833 21.7375 14.6833 21.2125 15.9C20.6875 17.1167 19.975 18.175 19.075 19.075C18.175 19.975 17.1167 20.6875 15.9 21.2125C14.6833 21.7375 13.3833 22 12 22ZM13 19.925C14.9833 19.675 16.6458 18.8042 17.9875 17.3125C19.3292 15.8208 20 14.05 20 12C20 9.95 19.3292 8.17917 17.9875 6.6875C16.6458 5.19583 14.9833 4.325 13 4.075V19.925Z"
        fill={color}
      />
    </G>
  </Svg>
);

export default Contrast;
