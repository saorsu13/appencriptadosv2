import React from 'react';
import { View, TextInput, StyleSheet, TouchableOpacity } from 'react-native';
import { useTheme } from '@shopify/restyle';
import { ThemeCustomType } from '@/config/theme2';
import SearchIcon from '@/assets/icons/SearchIcon';
import { useTranslation } from 'react-i18next';

interface SearchBarProps {
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  onSubmit?: () => void;
}

export default function SearchBar({
  value,
  onChangeText,
  placeholder,
  onSubmit,
}: SearchBarProps) {
  const { colors } = useTheme<ThemeCustomType>();
  const { t } = useTranslation();

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: colors.backgroundAlternate,
          borderColor: colors.strokeBorder,
        },
      ]}
    >
      <TextInput
        style={[styles.input, { color: colors.primaryText }]}
        placeholder={placeholder ?? t('pages.home-tab.searchPlaceholder')}
        placeholderTextColor={colors.secondaryText}
        value={value}
        onChangeText={onChangeText}
        returnKeyType="search"
        onSubmitEditing={onSubmit}
        underlineColorAndroid="transparent"
      />
      <TouchableOpacity
        onPress={onSubmit}
        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
      >
        <SearchIcon width={24} height={24} color={colors.secondaryText} />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 40,
    borderWidth: 1,
    paddingHorizontal: 30,
    height: 52,
    marginTop: 30,
    marginHorizontal: 22,
  },
  input: {
    flex: 1,
    fontSize: 14,
    fontWeight: '600',
    paddingVertical: 0,
    marginRight: 8,
  },
});
